# DevAI — VS Code Extension

A sidebar chat assistant for your code. Sends your current file, selected code, and your prompt to a local AI API at `http://localhost:8000/askAI`.

## Features

- **Chat sidebar** — lives in VS Code's primary sidebar under its own activity bar icon
- **Current file context** — attach the entire file being edited with one click
- **Selection context** — attach only the code you've highlighted
- **Quick prompts** — one-click buttons for "Explain this", "Fix bugs", "Refactor", "Write tests"
- **Right-click menu** — "DevAI: Send Current File" / "DevAI: Send Selected Code" from the editor context menu
- **Configurable API URL** — change the endpoint in VS Code settings (`devai.apiUrl`)

## Project Structure

```
devai-extension/
├── src/
│   ├── extension.ts               # Extension entry point; registers commands & view provider
│   └── providers/
│       └── ChatViewProvider.ts    # Webview panel with full chat UI + API integration
├── media/
│   └── devai-icon.svg             # Activity bar icon
├── esbuild.mjs                    # Bundle script (esbuild, CJS, externals: vscode)
├── tsconfig.json
└── package.json                   # Extension manifest (contributes, commands, views)
```

## API Contract

The extension sends a POST request to `http://localhost:8000/askAI` (configurable):

```json
{
  "prompt": "Explain what this code does",
  "fileName": "utils.ts",
  "language": "typescript",
  "fileContent": "// full file text...",
  "selection": "// selected snippet..."
}
```

`fileContent` and `selection` are only included when the user has enabled those checkboxes in the context bar.

The extension reads the response from any of these keys (first found wins):
`response`, `answer`, `message`, `result` — or falls back to the full JSON if none match.

## Development

```bash
# Install dependencies
pnpm install

# Build once
node esbuild.mjs

# Watch mode (rebuild on save)
node esbuild.mjs --watch

# Typecheck
npx tsc --noEmit

# Package as .vsix
pnpm run package
```

## Installing in VS Code

1. Build: `node esbuild.mjs`
2. Package: `pnpm run package` → produces `devai-0.1.0.vsix`
3. In VS Code: **Extensions → ⋯ → Install from VSIX…** → select the file

Or during development: open the `devai-extension/` folder in VS Code and press **F5** to launch an Extension Development Host.

## Configuration

| Setting | Default | Description |
|---|---|---|
| `devai.apiUrl` | `http://localhost:8000/askAI` | The POST endpoint for your local AI backend |
