import * as vscode from "vscode";

export interface CodeContext {
  fileName: string;
  fileContent: string;
  language: string;
  selection: string;
}

interface ChatMessage {
  role: "user" | "assistant" | "error";
  content: string;
  timestamp: string;
}

export class ChatViewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = "devai.chatView";

  private _view?: vscode.WebviewView;
  private _pendingContext: CodeContext | null = null;
  private _messages: ChatMessage[] = [];

  constructor(
    private readonly _extensionUri: vscode.Uri,
    private readonly _context: vscode.ExtensionContext
  ) {}

  public resolveWebviewView(
    webviewView: vscode.WebviewView,
    _context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ) {
    this._view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [this._extensionUri],
    };

    webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

    webviewView.webview.onDidReceiveMessage(async (message) => {
      switch (message.command) {
        case "sendMessage":
          await this._handleSendMessage(message.prompt, message.includeFile, message.includeSelection);
          break;
        case "clearChat":
          this._messages = [];
          this._pendingContext = null;
          this._view?.webview.postMessage({ command: "clearChat" });
          break;
        case "getActiveContext":
          this._pushActiveContext();
          break;
      }
    });

    if (this._pendingContext) {
      this._pushContext(this._pendingContext);
      this._pendingContext = null;
    }
  }

  public injectContext(ctx: CodeContext) {
    if (this._view) {
      this._pushContext(ctx);
    } else {
      this._pendingContext = ctx;
    }
  }

  public clearChat() {
    this._messages = [];
    this._pendingContext = null;
    this._view?.webview.postMessage({ command: "clearChat" });
  }

  private _pushContext(ctx: CodeContext) {
    this._view?.webview.postMessage({ command: "setContext", context: ctx });
  }

  private _pushActiveContext() {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      return;
    }
    const selection = editor.selection;
    const selectedText = editor.document.getText(selection);
    const ctx: CodeContext = {
      fileName: editor.document.fileName.split(/[\\/]/).pop() ?? "file",
      fileContent: editor.document.getText(),
      language: editor.document.languageId,
      selection: selectedText,
    };
    this._view?.webview.postMessage({ command: "setContext", context: ctx });
  }

  private async _handleSendMessage(
    prompt: string,
    includeFile: boolean,
    includeSelection: boolean
  ) {
    const editor = vscode.window.activeTextEditor;
    const config = vscode.workspace.getConfiguration("devai");
    const apiUrl = config.get<string>("apiUrl", "http://localhost:8000/askAI");

    const payload: Record<string, string> = { prompt };

    if (editor) {
      payload.language = editor.document.languageId;
      payload.fileName = editor.document.fileName.split(/[\\/]/).pop() ?? "file";

      if (includeFile) {
        payload.fileContent = editor.document.getText();
      }

      if (includeSelection) {
        const sel = editor.selection;
        const selectedText = editor.document.getText(sel);
        if (selectedText) {
          payload.selection = selectedText;
        }
      }
    }

    const userMsg: ChatMessage = {
      role: "user",
      content: prompt,
      timestamp: new Date().toLocaleTimeString(),
    };
    this._messages.push(userMsg);
    this._view?.webview.postMessage({ command: "addMessage", message: userMsg });
    this._view?.webview.postMessage({ command: "setLoading", loading: true });

    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`API returned ${response.status}: ${response.statusText}`);
      }

      const data = (await response.json()) as { response?: string; answer?: string; message?: string; result?: string };
      const replyText =
        data.response ?? data.answer ?? data.message ?? data.result ?? JSON.stringify(data);

      const assistantMsg: ChatMessage = {
        role: "assistant",
        content: replyText,
        timestamp: new Date().toLocaleTimeString(),
      };
      this._messages.push(assistantMsg);
      this._view?.webview.postMessage({ command: "addMessage", message: assistantMsg });
    } catch (err) {
      const errorMsg: ChatMessage = {
        role: "error",
        content: err instanceof Error ? err.message : String(err),
        timestamp: new Date().toLocaleTimeString(),
      };
      this._messages.push(errorMsg);
      this._view?.webview.postMessage({ command: "addMessage", message: errorMsg });
    } finally {
      this._view?.webview.postMessage({ command: "setLoading", loading: false });
    }
  }

  private _getHtmlForWebview(_webview: vscode.Webview): string {
    return /* html */ `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';" />
  <title>DevAI</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: var(--vscode-font-family);
      font-size: var(--vscode-font-size);
      color: var(--vscode-foreground);
      background: var(--vscode-sideBar-background);
      display: flex;
      flex-direction: column;
      height: 100vh;
      overflow: hidden;
    }

    /* ── Header ── */
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      border-bottom: 1px solid var(--vscode-sideBarSectionHeader-border, var(--vscode-panel-border));
      background: var(--vscode-sideBarSectionHeader-background);
      flex-shrink: 0;
    }
    .header-title {
      font-weight: 600;
      font-size: 11px;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: var(--vscode-sideBarSectionHeader-foreground);
    }
    .header-actions { display: flex; gap: 4px; }
    .icon-btn {
      background: none;
      border: none;
      cursor: pointer;
      color: var(--vscode-icon-foreground);
      padding: 3px 5px;
      border-radius: 3px;
      font-size: 14px;
      line-height: 1;
      opacity: 0.7;
      transition: opacity 0.15s, background 0.15s;
    }
    .icon-btn:hover { opacity: 1; background: var(--vscode-toolbar-hoverBackground); }

    /* ── Context bar ── */
    .context-bar {
      padding: 6px 10px;
      background: var(--vscode-editorWidget-background, var(--vscode-input-background));
      border-bottom: 1px solid var(--vscode-panel-border);
      flex-shrink: 0;
      display: none;
      gap: 6px;
      flex-direction: column;
    }
    .context-bar.visible { display: flex; }
    .context-file {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: var(--vscode-descriptionForeground);
    }
    .context-file strong {
      color: var(--vscode-foreground);
      font-weight: 500;
    }
    .context-badge {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      padding: 1px 6px;
      border-radius: 10px;
      font-size: 10px;
      font-weight: 500;
      background: var(--vscode-badge-background);
      color: var(--vscode-badge-foreground);
    }
    .context-options {
      display: flex;
      gap: 10px;
    }
    .ctx-check {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      cursor: pointer;
      color: var(--vscode-foreground);
      user-select: none;
    }
    .ctx-check input { cursor: pointer; accent-color: var(--vscode-focusBorder); }
    .ctx-dismiss {
      align-self: flex-end;
      background: none;
      border: none;
      font-size: 10px;
      color: var(--vscode-descriptionForeground);
      cursor: pointer;
      text-decoration: underline;
    }

    /* ── Messages ── */
    .messages {
      flex: 1;
      overflow-y: auto;
      padding: 10px 10px 4px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      scroll-behavior: smooth;
    }
    .messages::-webkit-scrollbar { width: 4px; }
    .messages::-webkit-scrollbar-track { background: transparent; }
    .messages::-webkit-scrollbar-thumb { background: var(--vscode-scrollbarSlider-background); border-radius: 4px; }

    .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 20px;
      text-align: center;
      color: var(--vscode-descriptionForeground);
      font-size: 12px;
    }
    .empty-icon { font-size: 28px; margin-bottom: 4px; opacity: 0.5; }

    .msg {
      display: flex;
      flex-direction: column;
      gap: 3px;
      animation: fadeIn 0.2s ease;
    }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }

    .msg-header {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 10px;
      color: var(--vscode-descriptionForeground);
    }
    .msg-role {
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .msg-role.user { color: var(--vscode-textLink-foreground); }
    .msg-role.assistant { color: var(--vscode-terminal-ansiGreen, #4ec9b0); }
    .msg-role.error { color: var(--vscode-errorForeground); }

    .msg-bubble {
      padding: 8px 10px;
      border-radius: 6px;
      font-size: 12px;
      line-height: 1.55;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .msg.user .msg-bubble {
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-input-border, transparent);
    }
    .msg.assistant .msg-bubble {
      background: var(--vscode-editorWidget-background, var(--vscode-sideBar-background));
      border: 1px solid var(--vscode-panel-border);
    }
    .msg.error .msg-bubble {
      background: var(--vscode-inputValidation-errorBackground);
      border: 1px solid var(--vscode-inputValidation-errorBorder);
      color: var(--vscode-errorForeground);
    }

    /* code blocks inside messages */
    .msg-bubble code {
      font-family: var(--vscode-editor-font-family, 'Courier New', monospace);
      font-size: 11px;
      background: var(--vscode-textBlockQuote-background);
      padding: 1px 4px;
      border-radius: 3px;
    }
    .msg-bubble pre {
      background: var(--vscode-textCodeBlock-background, #1e1e1e);
      border: 1px solid var(--vscode-panel-border);
      border-radius: 5px;
      padding: 8px 10px;
      overflow-x: auto;
      margin-top: 6px;
    }
    .msg-bubble pre code { background: none; padding: 0; }

    /* ── Typing indicator ── */
    .typing-indicator {
      display: none;
      align-items: center;
      gap: 4px;
      padding: 0 2px;
    }
    .typing-indicator.visible { display: flex; }
    .dot {
      width: 5px; height: 5px;
      border-radius: 50%;
      background: var(--vscode-descriptionForeground);
      animation: bounce 1.2s infinite;
    }
    .dot:nth-child(2) { animation-delay: 0.2s; }
    .dot:nth-child(3) { animation-delay: 0.4s; }
    @keyframes bounce {
      0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
      40% { transform: translateY(-4px); opacity: 1; }
    }

    /* ── Input area ── */
    .input-area {
      padding: 8px 10px 10px;
      border-top: 1px solid var(--vscode-panel-border);
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex-shrink: 0;
    }

    .quick-actions {
      display: flex;
      gap: 5px;
    }
    .quick-btn {
      flex: 1;
      padding: 4px 6px;
      font-size: 10px;
      background: var(--vscode-button-secondaryBackground);
      color: var(--vscode-button-secondaryForeground);
      border: 1px solid var(--vscode-button-border, transparent);
      border-radius: 4px;
      cursor: pointer;
      text-align: center;
      transition: background 0.15s;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .quick-btn:hover { background: var(--vscode-button-secondaryHoverBackground); }

    .textarea-wrap {
      position: relative;
    }
    textarea {
      width: 100%;
      resize: none;
      padding: 8px 10px;
      font-family: var(--vscode-font-family);
      font-size: 12px;
      color: var(--vscode-input-foreground);
      background: var(--vscode-input-background);
      border: 1px solid var(--vscode-input-border, transparent);
      border-radius: 5px;
      outline: none;
      line-height: 1.5;
      min-height: 70px;
      max-height: 160px;
      overflow-y: auto;
      transition: border-color 0.15s;
    }
    textarea::placeholder { color: var(--vscode-input-placeholderForeground); }
    textarea:focus { border-color: var(--vscode-focusBorder); }

    .send-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .send-hint {
      font-size: 10px;
      color: var(--vscode-descriptionForeground);
    }
    .send-btn {
      padding: 5px 14px;
      font-size: 12px;
      font-weight: 500;
      background: var(--vscode-button-background);
      color: var(--vscode-button-foreground);
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.15s, opacity 0.15s;
    }
    .send-btn:hover { background: var(--vscode-button-hoverBackground); }
    .send-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  </style>
</head>
<body>

  <div class="header">
    <span class="header-title">DevAI Chat</span>
    <div class="header-actions">
      <button class="icon-btn" id="btn-grab-file" title="Load current file context">⊙ File</button>
      <button class="icon-btn" id="btn-clear" title="Clear chat">✕</button>
    </div>
  </div>

  <div class="context-bar" id="context-bar">
    <div class="context-file">
      <span>📄</span>
      <strong id="ctx-filename">—</strong>
      <span class="context-badge" id="ctx-lang-badge"></span>
      <span id="ctx-sel-badge" class="context-badge" style="display:none;">Selection</span>
    </div>
    <div class="context-options">
      <label class="ctx-check">
        <input type="checkbox" id="chk-file" checked />
        Include full file
      </label>
      <label class="ctx-check" id="lbl-sel" style="display:none;">
        <input type="checkbox" id="chk-selection" checked />
        Include selection
      </label>
    </div>
    <button class="ctx-dismiss" id="ctx-dismiss">Remove context</button>
  </div>

  <div class="messages" id="messages">
    <div class="empty-state" id="empty-state">
      <div class="empty-icon">🤖</div>
      <strong>DevAI</strong>
      <span>Ask anything about your code.<br/>Use the buttons above to load file or selection context.</span>
    </div>
  </div>

  <div class="typing-indicator" id="typing">
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
  </div>

  <div class="input-area">
    <div class="quick-actions">
      <button class="quick-btn" id="qa-explain">Explain this</button>
      <button class="quick-btn" id="qa-fix">Fix bugs</button>
      <button class="quick-btn" id="qa-refactor">Refactor</button>
      <button class="quick-btn" id="qa-test">Write tests</button>
    </div>
    <div class="textarea-wrap">
      <textarea id="prompt" placeholder="Ask DevAI anything about your code…" rows="3"></textarea>
    </div>
    <div class="send-row">
      <span class="send-hint">Ctrl+Enter to send</span>
      <button class="send-btn" id="send-btn">Send</button>
    </div>
  </div>

<script>
  const vscode = acquireVsCodeApi();

  let currentContext = null;

  const messagesEl = document.getElementById('messages');
  const emptyState = document.getElementById('empty-state');
  const promptEl = document.getElementById('prompt');
  const sendBtn = document.getElementById('send-btn');
  const typingEl = document.getElementById('typing');
  const contextBar = document.getElementById('context-bar');
  const ctxFilename = document.getElementById('ctx-filename');
  const ctxLangBadge = document.getElementById('ctx-lang-badge');
  const ctxSelBadge = document.getElementById('ctx-sel-badge');
  const lblSel = document.getElementById('lbl-sel');
  const chkFile = document.getElementById('chk-file');
  const chkSel = document.getElementById('chk-selection');

  function renderMarkdown(text) {
    return text
      .replace(/\x60\x60\x60([\s\S]*?)\x60\x60\x60/g, (_, code) => '<pre><code>' + escHtml(code.trim()) + '</code></pre>')
      .replace(/\x60([^\x60]+)\x60/g, (_, code) => '<code>' + escHtml(code) + '</code>')
      .replace(/&(?!amp;|lt;|gt;|quot;|#)/g, '&amp;');
  }

  function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function addMessage(msg) {
    emptyState.style.display = 'none';
    const div = document.createElement('div');
    div.className = 'msg ' + msg.role;
    div.innerHTML =
      '<div class="msg-header"><span class="msg-role ' + msg.role + '">' +
        (msg.role === 'user' ? 'You' : msg.role === 'assistant' ? 'DevAI' : 'Error') +
      '</span><span>' + msg.timestamp + '</span></div>' +
      '<div class="msg-bubble">' + renderMarkdown(msg.content) + '</div>';
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function setContext(ctx) {
    currentContext = ctx;
    contextBar.classList.add('visible');
    ctxFilename.textContent = ctx.fileName;
    ctxLangBadge.textContent = ctx.language || 'text';
    if (ctx.selection) {
      ctxSelBadge.style.display = 'inline-flex';
      lblSel.style.display = 'flex';
    } else {
      ctxSelBadge.style.display = 'none';
      lblSel.style.display = 'none';
    }
  }

  function sendMessage() {
    const prompt = promptEl.value.trim();
    if (!prompt || sendBtn.disabled) return;
    vscode.postMessage({
      command: 'sendMessage',
      prompt,
      includeFile: chkFile.checked,
      includeSelection: chkSel.checked,
    });
    promptEl.value = '';
    promptEl.style.height = 'auto';
  }

  sendBtn.addEventListener('click', sendMessage);

  promptEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      sendMessage();
    }
  });

  promptEl.addEventListener('input', () => {
    promptEl.style.height = 'auto';
    promptEl.style.height = Math.min(promptEl.scrollHeight, 160) + 'px';
  });

  document.getElementById('btn-clear').addEventListener('click', () => {
    vscode.postMessage({ command: 'clearChat' });
  });

  document.getElementById('btn-grab-file').addEventListener('click', () => {
    vscode.postMessage({ command: 'getActiveContext' });
  });

  document.getElementById('ctx-dismiss').addEventListener('click', () => {
    currentContext = null;
    contextBar.classList.remove('visible');
  });

  const quickPrompts = {
    'qa-explain': 'Explain what this code does in plain English.',
    'qa-fix': 'Identify and fix any bugs in this code.',
    'qa-refactor': 'Refactor this code for clarity, performance, and best practices.',
    'qa-test': 'Write unit tests for this code.',
  };
  Object.entries(quickPrompts).forEach(([id, text]) => {
    document.getElementById(id).addEventListener('click', () => {
      promptEl.value = text;
      promptEl.focus();
    });
  });

  window.addEventListener('message', (event) => {
    const msg = event.data;
    switch (msg.command) {
      case 'addMessage':
        addMessage(msg.message);
        break;
      case 'setLoading':
        sendBtn.disabled = msg.loading;
        typingEl.classList.toggle('visible', msg.loading);
        if (msg.loading) messagesEl.scrollTop = messagesEl.scrollHeight;
        break;
      case 'setContext':
        setContext(msg.context);
        break;
      case 'clearChat':
        messagesEl.innerHTML = '';
        messagesEl.appendChild(emptyState);
        emptyState.style.display = 'flex';
        currentContext = null;
        contextBar.classList.remove('visible');
        break;
    }
  });
</script>
</body>
</html>`;
  }
}
