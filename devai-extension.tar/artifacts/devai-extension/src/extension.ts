import * as vscode from "vscode";
import { ChatViewProvider } from "./providers/ChatViewProvider";

export function activate(context: vscode.ExtensionContext) {
  const provider = new ChatViewProvider(context.extensionUri, context);

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(ChatViewProvider.viewType, provider, {
      webviewOptions: { retainContextWhenHidden: true },
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("devai.sendCurrentFile", () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage("DevAI: No active file open.");
        return;
      }
      const fileContent = editor.document.getText();
      const fileName = editor.document.fileName.split(/[\\/]/).pop() ?? "file";
      const language = editor.document.languageId;
      provider.injectContext({ fileName, fileContent, language, selection: "" });
      vscode.commands.executeCommand("devai.chatView.focus");
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("devai.sendSelection", () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage("DevAI: No active editor.");
        return;
      }
      const selection = editor.selection;
      const selectedText = editor.document.getText(selection);
      if (!selectedText) {
        vscode.window.showWarningMessage("DevAI: No text selected.");
        return;
      }
      const fileContent = editor.document.getText();
      const fileName = editor.document.fileName.split(/[\\/]/).pop() ?? "file";
      const language = editor.document.languageId;
      provider.injectContext({ fileName, fileContent, language, selection: selectedText });
      vscode.commands.executeCommand("devai.chatView.focus");
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand("devai.clearChat", () => {
      provider.clearChat();
    })
  );
}

export function deactivate() {}
